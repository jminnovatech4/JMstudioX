
package com.jmstudiox.app.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.jmstudiox.app.data.model.*
import com.jmstudiox.app.engine.FfmpegEngine
import com.jmstudiox.app.repository.MediaStoreRepository
import com.jmstudiox.app.ui.components.*
import com.jmstudiox.app.utils.MediaUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.roundToInt

@Composable
fun VideoEditorScreen(
    uri: Uri,
    fileName: String,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine = remember { FfmpegEngine(context) }

    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    var state by remember { mutableStateOf(EditState()) }
    var selectedTool by remember { mutableStateOf(EditorTool.TRIM) }
    var processing by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var resultFile by remember { mutableStateOf<File?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var extraClipUris by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var showTextDialog by remember { mutableStateOf(false) }
    var textValue by remember { mutableStateOf("") }

    val logoPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { picked ->
        if (picked != null) {
            try {
                val file = MediaUtils.copyToCache(context, picked, "watermark.png")
                state = state.copy(watermarkPath = file.absolutePath)
                message = "Logo added to the timeline."
            } catch (e: Exception) {
                message = e.message ?: "Could not read logo."
            }
        }
    }

    val clipPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(20)
    ) { picked ->
        if (picked.isNotEmpty()) extraClipUris = (extraClipUris + picked).distinct()
    }

    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
        }
    }

    DisposableEffect(player) {
        val listener = object : androidx.media3.common.Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == androidx.media3.common.Player.STATE_READY) {
                    duration = player.duration.coerceAtLeast(1L)
                    if (state.endMs == Long.MAX_VALUE) {
                        state = state.copy(endMs = duration)
                    }
                }
            }
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playing = isPlaying
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            delay(150)
        }
    }

    LaunchedEffect(state.volume) {
        player.volume = if (state.mute) 0f else state.volume
    }

    LaunchedEffect(state.speed) {
        player.setPlaybackSpeed(state.speed)
    }

    fun export() {
        if (duration <= 0L) {
            message = "Video duration is not ready yet."
            return
        }
        if (state.endMs <= state.startMs) {
            message = "End must be greater than start."
            return
        }
        scope.launch {
            processing = true
            progress = 0
            resultFile = null
            val mainInput = try {
                MediaUtils.copyToCache(context, uri, fileName)
            } catch (e: Exception) {
                processing = false
                message = e.message ?: "Could not read the selected video."
                return@launch
            }

            val allInputs = mutableListOf(mainInput)
            try {
                extraClipUris.forEachIndexed { index, clip ->
                    allInputs += MediaUtils.copyToCache(context, clip, "clip_$index.mp4")
                }
            } catch (e: Exception) {
                processing = false
                message = e.message ?: "Could not read one of the added clips."
                return@launch
            }

            fun renderFinal(input: File, exportDurationMs: Long) {
                val finalState = if (allInputs.size > 1) {
                    state.copy(startMs = 0L, endMs = exportDurationMs).normalized(exportDurationMs)
                } else {
                    state.normalized(exportDurationMs)
                }
                engine.export(
                    input = input,
                    state = finalState,
                    inputDurationMs = exportDurationMs,
                    onProgress = { p -> progress = p },
                    onSuccess = { file ->
                        processing = false
                        resultFile = file
                        message = "Export completed successfully."
                    },
                    onError = { error ->
                        processing = false
                        message = error
                    }
                )
            }

            if (allInputs.size == 1) {
                renderFinal(mainInput, duration)
            } else {
                val totalDuration = duration + extraClipUris.sumOf { MediaUtils.durationMs(context, it) }
                engine.merge(
                    inputs = allInputs,
                    onProgress = { p -> progress = p.coerceIn(0, 99) },
                    onSuccess = { merged -> renderFinal(merged, totalDuration.coerceAtLeast(duration)) },
                    onError = { error ->
                        processing = false
                        message = error
                    }
                )
            }
        }
    }


    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
            }
            Column(Modifier.weight(1f)) {
                Text("JM StudioX Pro Editor", style = MaterialTheme.typography.titleLarge)
                Text(fileName, style = MaterialTheme.typography.labelSmall)
            }
            Button(
                onClick = ::export,
                enabled = !processing && duration > 0L
            ) {
                Icon(Icons.Default.FileUpload, null)
                Spacer(Modifier.width(6.dp))
                Text("Export")
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    clipPicker.launch(
                        PickVisualMediaRequest(
                            ActivityResultContracts.PickVisualMedia.ImageAndVideo
                        )
                    )
                }
            ) {
                Icon(Icons.Default.AddToPhotos, null)

                Spacer(
                    Modifier.width(6.dp)
                )

                Text("Add clips")
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                val exoPlayer = player
                AndroidView(
                    factory = { context ->
                        PlayerView(context).apply {
                            useController = true
                            this.player = exoPlayer
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            IconButton(onClick = {
                if (playing) player.pause() else player.play()
            }) {
                Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null)
            }
            IconButton(onClick = {
                player.seekTo(state.startMs.coerceIn(0L, duration))
            }) {
                Icon(Icons.Default.SkipPrevious, null)
            }
            IconButton(onClick = {
                player.seekTo(state.endMs.coerceAtMost(duration))
            }) {
                Icon(Icons.Default.SkipNext, null)
            }
        }

        TimelineEditor(
            durationMs = duration,
            positionMs = position,
            startMs = state.startMs,
            endMs = state.endMs.coerceAtMost(duration),
            onStartChanged = { value ->
                state = state.copy(startMs = value.coerceAtMost(state.endMs - 250))
                player.seekTo(state.startMs)
            },
            onEndChanged = { value ->
                state = state.copy(endMs = value.coerceAtLeast(state.startMs + 250))
            },
            onSeek = { player.seekTo(it) }
        )

        EditorToolBar(selectedTool, onSelected = { selectedTool = it })

        when (selectedTool) {
            EditorTool.TRIM -> TrimPanel(state, duration) { state = it }
            EditorTool.SPEED -> SpeedPanel(state) {
                state = state.copy(speed = it)
                player.setPlaybackSpeed(it)
            }
            EditorTool.AUDIO -> AudioPanel(state) { state = it }
            EditorTool.ADJUST -> AdjustPanel(state) { state = it }
            EditorTool.CROP -> CropPanel(state) { state = it }
            EditorTool.ROTATE -> RotatePanel(state) { state = it }
            EditorTool.TEXT -> TextPanel(
                state = state,
                onAdd = { textValue = ""; showTextDialog = true },
                onRemove = { state = state.copy(textOverlay = null) }
            )
            EditorTool.WATERMARK -> WatermarkPanel(
                state = state,
                onPick = { logoPicker.launch("image/*") },
                onPathChanged = { state = state.copy(watermarkPath = it) }
            )
        }

        Text(
            "Edits are combined and rendered by FFmpeg only when you tap Export.",
            style = MaterialTheme.typography.labelSmall
        )

        resultFile?.let { file ->
            ResultCard(
                file = file,
                onSave = {
                    val ok = MediaStoreRepository.saveVideo(
                        context, file, "JMStudioX_${System.currentTimeMillis()}"
                    )
                    message = if (ok) "Saved to Gallery / Movies / JM StudioX" else "Could not save to Gallery."
                },
                onShare = {
                    try {
                        val contentUri = FileProvider.getUriForFile(
                            context,
                            "${context.packageName}.fileprovider",
                            file
                        )
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "video/mp4"
                            putExtra(Intent.EXTRA_STREAM, contentUri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        context.startActivity(Intent.createChooser(intent, "Share video"))
                    } catch (e: Exception) {
                        message = e.message ?: "Could not open the share sheet."
                    }
                }
            )
        }
    }

    if (processing) {
        ProcessingOverlay(progress, "Exporting with FFmpeg…") {
            engine.cancel()
            processing = false
        }
    }

    if (showTextDialog) {
        AlertDialog(
            onDismissRequest = { showTextDialog = false },
            title = { Text("Add text") },
            text = {
                OutlinedTextField(
                    value = textValue,
                    onValueChange = { textValue = it },
                    label = { Text("Text") },
                    singleLine = false
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        state = state.copy(textOverlay = TextOverlayState(textValue))
                        showTextDialog = false
                    }
                ) { Text("Add") }
            },
            dismissButton = { TextButton(onClick = { showTextDialog = false }) { Text("Cancel") } }
        )
    }

    message?.let {
        AlertDialog(
            onDismissRequest = { message = null },
            title = { Text("JM StudioX") },
            text = { Text(it) },
            confirmButton = { Button(onClick = { message = null }) { Text("OK") } }
        )
    }
}

@Composable
private fun TrimPanel(state: EditState, duration: Long, onChanged: (EditState) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Trim / Cut", style = MaterialTheme.typography.titleMedium)
            Text("${MediaUtils.formatTime(state.startMs)} → ${MediaUtils.formatTime(state.endMs.coerceAtMost(duration))}")
            Text("The selected range is rendered into the final file.")
        }
    }
}

@Composable
private fun SpeedPanel(state: EditState, onChanged: (Float) -> Unit) {
    val values = listOf(.25f, .5f, .75f, 1f, 1.25f, 1.5f, 2f, 3f, 4f)
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Speed", style = MaterialTheme.typography.titleMedium)
            Text(String.format("%.2fx", state.speed))
            Slider(
                value = values.indexOf(state.speed).coerceAtLeast(0).toFloat(),
                onValueChange = { raw ->
                    onChanged(values[raw.roundToInt().coerceIn(0, values.lastIndex)])
                },
                valueRange = 0f..values.lastIndex.toFloat(),
                steps = values.size - 2
            )
        }
    }
}

@Composable
private fun AudioPanel(state: EditState, onChanged: (EditState) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Audio", style = MaterialTheme.typography.titleMedium)
            Text("Volume ${String.format("%.0f%%", state.volume * 100)}")
            Slider(value = state.volume, onValueChange = { onChanged(state.copy(volume = it)) }, valueRange = 0f..2f)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Mute")
                Switch(checked = state.mute, onCheckedChange = { onChanged(state.copy(mute = it)) })
            }
        }
    }
}

@Composable
private fun AdjustPanel(state: EditState, onChanged: (EditState) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Adjust", style = MaterialTheme.typography.titleMedium)
            LabeledSlider("Brightness", state.brightness, -1f..1f) { onChanged(state.copy(brightness = it)) }
            LabeledSlider("Contrast", state.contrast, .2f..2f) { onChanged(state.copy(contrast = it)) }
            LabeledSlider("Saturation", state.saturation, 0f..2f) { onChanged(state.copy(saturation = it)) }
        }
    }
}

@Composable
private fun LabeledSlider(
    title: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit
) {
    Text("$title ${String.format("%.2f", value)}")
    Slider(value = value, onValueChange = onChange, valueRange = range)
}

@Composable
private fun CropPanel(state: EditState, onChanged: (EditState) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Crop / Aspect Ratio", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("free", "1:1", "16:9", "9:16", "4:5").forEach { ratio ->
                    FilterChip(
                        selected = state.crop?.aspect == ratio,
                        onClick = { onChanged(state.copy(crop = if (ratio == "free") null else CropState(ratio))) },
                        label = { Text(ratio) }
                    )
                }
            }
        }
    }
}

@Composable
private fun RotatePanel(state: EditState, onChanged: (EditState) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(14.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            OutlinedButton(onClick = { onChanged(state.copy(rotation = (state.rotation + 270) % 360)) }) {
                Text("↶ 90°")
            }
            Text("${state.rotation}°", style = MaterialTheme.typography.titleMedium)
            OutlinedButton(onClick = { onChanged(state.copy(rotation = (state.rotation + 90) % 360)) }) {
                Text("90° ↷")
            }
        }
    }
}

@Composable
private fun TextPanel(
    state: EditState,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(state.textOverlay?.text ?: "No text layer")
            Row {
                Button(onClick = onAdd) { Text("Add") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = onRemove) { Text("Remove") }
            }
        }
    }
}

@Composable
private fun WatermarkPanel(
    state: EditState,
    onPick: () -> Unit,
    onPathChanged: (String?) -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Text("Logo / Watermark", style = MaterialTheme.typography.titleMedium)
            Text(
                state.watermarkPath ?: "Choose a logo image and wire the Android picker to this path.",
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onPick) { Text("Choose Logo") }
                OutlinedButton(onClick = { onPathChanged(null) }) { Text("Clear") }
            }
        }
    }
}

@Composable
private fun ResultCard(
    file: File,
    onSave: () -> Unit,
    onShare: () -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Export ready", style = MaterialTheme.typography.titleMedium)
            Text(file.name)
            Text(MediaUtils.fileSize(file), style = MaterialTheme.typography.labelSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onSave) {
                    Icon(Icons.Default.Save, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Save to Gallery")
                }
                OutlinedButton(onClick = onShare) {
                    Icon(Icons.Default.Share, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Share")
                }
            }
        }
    }
}

